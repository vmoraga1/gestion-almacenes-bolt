<?php
/**
 * Plugin Name: Force OpenPOS Receipt Print
 * Description: Forzar impresión de recibos en OpenPOS con logs para depuración.
 * Version: 1.0
 * Author: Víctor Moraga
 */

add_action('admin_footer', 'fopr_inyectar_js_openpos');

function fopr_inyectar_js_openpos() {
    $screen = get_current_screen();
    if ($screen && strpos($screen->id, 'woocommerce-openpos') !== false) {
        ?>
        <script>
        (function waitForOpenPOS() {
            const interval = setInterval(function () {
                try {
                    if (
                        typeof window.OpenPos !== 'undefined' &&
                        typeof OpenPos.orderService !== 'undefined' &&
                        typeof OpenPos.orderService.saveOrder === 'function'
                    ) {
                        clearInterval(interval);

                        const originalSaveOrder = OpenPos.orderService.saveOrder;

                        OpenPos.orderService.saveOrder = function (order, callback) {
                            console.log("F-Recibo saveOrder INTERCEPTADO");

                            originalSaveOrder.call(this, order, function (response) {
                                console.log("F-Recibo Orden guardada:", response);

                                if (typeof callback === 'function') {
                                    callback(response);
                                }

                                try {
                                    const numCopies = OpenPos.appService.getNumberCopyReceiptPrint() || 1;
                                    console.log("F-Recibo Imprimiendo recibo forzadamente...");
                                    OpenPos.orderService.printReceipt(response, "receipt", numCopies);
                                } catch (err) {
                                    console.error("F-Recibo Error al imprimir el recibo:", err);
                                }
                            });
                        };

                        console.log("F-Recibo Monkey patch aplicado a saveOrder()");
                    }
                } catch (err) {
                    console.error("F-Recibo Error en monkey patch:", err);
                }
            }, 500);
        })();
        </script>
        <?php
    }
}